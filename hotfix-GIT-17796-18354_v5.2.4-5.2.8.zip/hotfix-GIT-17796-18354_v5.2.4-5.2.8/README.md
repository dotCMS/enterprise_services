GitHub ticket:
https://github.com/dotCMS/core/issues/17796
https://github.com/dotCMS/core/issues/18354

dotCMS Version: 5.2.4-5.2.8
